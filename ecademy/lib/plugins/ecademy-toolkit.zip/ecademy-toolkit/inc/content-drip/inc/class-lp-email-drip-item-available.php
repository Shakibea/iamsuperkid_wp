<?php
/**
 * ECA_LP_Email_Drip_Item_Available
 *
 * @author   EnvyTheme
 * @package  LearnPress/Content-Drip/Classes

 */

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'ECA_LP_Email_Drip_Item_Available' ) ) {

	/**
	 * Class ECA_LP_Email_Drip_Item_Available
	 */
	class ECA_LP_Email_Drip_Item_Available extends LP_Email {

		/**
		 * ECA_LP_Email_Drip_Item_Available constructor.
		 */
		public function __construct() {

			$this->id          = 'drip-item-available';
			$this->title       = __( 'Drip Item Available', 'ecademy-toolkit' );
			$this->description = __( 'Send this email to user when an item was blocked become available.', 'learnpress-co-instructor' );


			$this->default_subject = __( '[{{site_title}}] Item available for learning', 'learnpress-co-instructor' );
			$this->default_heading = __( '{{item_name}} has become available.', 'learnpress-co-instructor' );

			$this->template_base  = '';
			$this->template_plain = 'emails/plain/drip-item-available.php';
			$this->template_html  = 'emails/drip-item-available.php';

			parent::__construct();
		}
	}
}

return new ECA_LP_Email_Drip_Item_Available();
?>