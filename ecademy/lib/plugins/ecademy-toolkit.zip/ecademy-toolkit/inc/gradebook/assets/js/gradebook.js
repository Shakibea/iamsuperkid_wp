;(function ($) {
    $(document).ready(function () {
        $('.gradebook-list').each(function () {
            $(this).thimFancyTable({
                fixedColumns: $(this).find('thead tr:first').children('.fixed-column').length,
                onCreate: function (table) {

                }
            });
        });
    })
})(jQuery);